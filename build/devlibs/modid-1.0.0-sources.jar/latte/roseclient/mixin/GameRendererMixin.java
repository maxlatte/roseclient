public class GameRendererMixin {
    
}
