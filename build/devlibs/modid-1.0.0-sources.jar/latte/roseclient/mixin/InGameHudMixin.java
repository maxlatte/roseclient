public class InGameHudMixin {
    
}
