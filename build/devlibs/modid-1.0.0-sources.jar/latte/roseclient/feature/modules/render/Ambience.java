public class Ambience {
    
}
