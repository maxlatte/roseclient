public class Nickname {
    
}
