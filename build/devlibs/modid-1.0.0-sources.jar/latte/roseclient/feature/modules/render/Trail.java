public class Trail {
    
}
