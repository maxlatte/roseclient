public class Waypoints {
    
}
