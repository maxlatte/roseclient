public class ChinaHat {
    
}
