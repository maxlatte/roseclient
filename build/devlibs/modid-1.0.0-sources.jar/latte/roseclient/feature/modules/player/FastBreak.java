public class FastBreak {
    
}
