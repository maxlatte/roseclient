public class FastUse {
    
}
