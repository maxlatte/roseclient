public class AirPlace {
    
}
