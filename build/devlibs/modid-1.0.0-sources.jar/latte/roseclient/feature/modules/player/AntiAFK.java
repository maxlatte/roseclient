public class AntiAFK {
    
}
