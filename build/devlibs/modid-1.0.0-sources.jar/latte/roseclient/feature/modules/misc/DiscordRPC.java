public class DiscordRPC {
    
}
