public class DisablerCubeCraft {
    
}
