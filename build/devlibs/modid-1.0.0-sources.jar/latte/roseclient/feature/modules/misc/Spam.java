public class Spam {
    
}
