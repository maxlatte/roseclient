public class TridentUse {
    
}
