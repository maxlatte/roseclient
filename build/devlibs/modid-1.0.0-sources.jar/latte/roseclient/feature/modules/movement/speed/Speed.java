public class Speed {
    
}
