public class NoSlow {
    
}
