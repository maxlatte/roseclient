public class FastClimb {
    
}
