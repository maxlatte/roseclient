public class SpeedModes {
    
}
