public class SpeedJump {
    
}
