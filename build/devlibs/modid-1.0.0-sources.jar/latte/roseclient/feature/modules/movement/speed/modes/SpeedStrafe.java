public class SpeedStrafe {
    
}
