public class VelocityHypixel {

}