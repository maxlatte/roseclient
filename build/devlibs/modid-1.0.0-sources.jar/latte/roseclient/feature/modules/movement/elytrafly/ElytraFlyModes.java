public class ElytraFlyModes {
    
}
