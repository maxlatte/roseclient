public class SpeedMode {
    
}
