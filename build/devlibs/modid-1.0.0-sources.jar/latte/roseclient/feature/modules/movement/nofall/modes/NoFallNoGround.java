public class NoFallNoGround {
    
}
