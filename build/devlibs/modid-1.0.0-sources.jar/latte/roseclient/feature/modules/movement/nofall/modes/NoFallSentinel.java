public class NoFallSentinel {
    
}
