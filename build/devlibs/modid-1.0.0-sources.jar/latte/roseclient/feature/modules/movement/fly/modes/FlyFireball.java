public class FlyFireball {
    
}
