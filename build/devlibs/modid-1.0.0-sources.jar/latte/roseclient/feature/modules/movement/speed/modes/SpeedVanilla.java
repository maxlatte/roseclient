public class SpeedVanilla {
    
}
