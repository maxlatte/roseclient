public class InventoryMove {
    
}
