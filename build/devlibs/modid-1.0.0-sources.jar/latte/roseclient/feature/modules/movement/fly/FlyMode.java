public class FlyMode {
    
}
