public class VelocityMode {
    
}
