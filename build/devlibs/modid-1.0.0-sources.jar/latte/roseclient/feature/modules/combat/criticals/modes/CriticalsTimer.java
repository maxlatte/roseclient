public class CriticalsTimer {
    
}
