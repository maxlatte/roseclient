public class CriticalsModes {
    
}
