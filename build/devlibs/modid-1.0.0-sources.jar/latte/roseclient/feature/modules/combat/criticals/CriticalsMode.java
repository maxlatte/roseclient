public class CriticalsMode {
    
}
