public class CriticalsPacket {
    
}
