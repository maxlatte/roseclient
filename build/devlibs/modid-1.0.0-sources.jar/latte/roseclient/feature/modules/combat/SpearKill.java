public class SpearKill {
    
}
