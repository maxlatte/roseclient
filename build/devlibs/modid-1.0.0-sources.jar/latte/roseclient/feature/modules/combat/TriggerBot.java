public class TriggerBot {
    
}
