public class CriticalsJump {

}