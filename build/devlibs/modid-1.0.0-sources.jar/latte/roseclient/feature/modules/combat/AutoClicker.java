public class AutoClicker {
    
}
