public class Criticals {
    
}
