public class AutoCrystal {
    
}
