public class CriticalsNoGround {
    
}
