public class AutoArmor {
    
}
