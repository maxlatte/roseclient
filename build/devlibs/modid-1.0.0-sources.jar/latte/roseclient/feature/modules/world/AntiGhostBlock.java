public class AntiGhostBlock {
    
}
