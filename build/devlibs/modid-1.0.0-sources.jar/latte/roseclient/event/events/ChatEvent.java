public class ChatEvent {
    
}
