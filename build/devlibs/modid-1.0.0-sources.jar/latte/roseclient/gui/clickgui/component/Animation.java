public class Animation {
    
}
