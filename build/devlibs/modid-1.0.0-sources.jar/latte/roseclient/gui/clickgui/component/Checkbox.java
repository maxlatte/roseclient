public class Checkbox {
    
}
