public class BooleanValue {
    
}
