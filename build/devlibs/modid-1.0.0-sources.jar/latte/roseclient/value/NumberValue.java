public class NumberValue {
    
}
