public class ColorValue {
    
}
