public class EnumValue {
    
}
