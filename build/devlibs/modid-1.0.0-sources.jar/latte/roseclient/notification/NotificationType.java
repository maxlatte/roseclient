public class NotificationType {
    
}
