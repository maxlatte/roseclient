public class Scissor {
    
}
